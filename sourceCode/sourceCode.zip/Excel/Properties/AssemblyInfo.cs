﻿using System.Reflection;
using System;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ExcelDataReader")]
[assembly: AssemblyDescription("Excel data reader for .Net")]
[assembly: AssemblyProduct("ExcelDataReader")]
[assembly: AssemblyVersion("2.1.2.3")]

[assembly: ComVisible(false)]

[assembly: Guid("e0bcbc74-51d2-48a3-bddb-b0b407516397")]

[assembly: CLSCompliant(true)]