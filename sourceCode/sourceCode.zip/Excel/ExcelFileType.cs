using System;
using System.Collections.Generic;
using System.Text;

namespace Excel
{
	public enum ExcelFileType
	{
		Binary,
		OpenXml
	}
}
