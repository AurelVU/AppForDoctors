using System;
using System.Collections.Generic;
using System.Text;

namespace Excel.Core.Binary12Format
{
	internal class XlsbSST : List<string>
	{
	}
}
