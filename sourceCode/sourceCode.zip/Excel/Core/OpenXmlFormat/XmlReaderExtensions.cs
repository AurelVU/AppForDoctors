﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Excel.Core.OpenXmlFormat
{
	public static class XmlReaderExtensions
	{
		//public bool 
	}
}
