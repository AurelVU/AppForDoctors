using System;
using System.Collections.Generic;
using System.Text;

namespace Excel.Core.OpenXmlFormat
{
	/// <summary>
	/// Shared string table
	/// </summary>
	internal class XlsxSST : List<string>
	{

	}
}
