namespace ExcelDataReader.Silverlight.Data
{
	public interface IWorkBookFactory
	{
		IWorkBook CreateWorkBook();
	}
}