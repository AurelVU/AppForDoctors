namespace ExcelDataReader.Silverlight.Data
{
	using System.Collections.Generic;

	public interface IWorkSheetCollection : ICollection<IWorkSheet>
	{
	}
}