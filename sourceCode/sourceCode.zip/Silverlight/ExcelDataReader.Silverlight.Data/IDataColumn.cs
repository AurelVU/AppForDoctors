namespace ExcelDataReader.Silverlight.Data
{
	public interface IDataColumn
	{
		string ColumnName { get; set; }
	}
}