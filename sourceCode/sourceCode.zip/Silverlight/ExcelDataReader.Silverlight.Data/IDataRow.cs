namespace ExcelDataReader.Silverlight.Data
{
	using System.Collections;

	public interface IDataRow
	{
		IList Values { get; set; }
	}
}